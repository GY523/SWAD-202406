<?php
include('../Controller/admin_auth.php');
require('../Model/database.php');
    
if(isset($_POST['new']) && $_POST['new']==1){
    $title = $_POST['title'];
    $image= $_POST['image'];
    $released_year=$_POST['released_year'];
    $lang= $_POST['language'];
    $runtime=$_POST['runtime'];
    $genre= $_POST['genre'];
    $overview= addslashes($_POST['overview']);
    $tagline= addslashes($_POST['tagline']);
    $cast = addslashes($_POST['cast']);
    $director= addslashes($_POST['director']);
    //generate new id 
    $sel_query= "SELECT movie_id from movie ORDER BY movie_id DESC LIMIT 1;";
    $result= mysqli_query($con,$sel_query) or die (mysqli_error($con));
    $row= mysqli_fetch_assoc($result);
    $largest_id=$row['movie_id'];
    //get the largest id +1 , that will be the new id
    $new_id="tt" .(intval(substr($largest_id,2))+1);
    
    $ins_query="INSERT into movie
    (`movie_id`,`title`,`image`,`released_year`,`language`,`runtime`,`genre`,`overview`,`tagline`,`cast`,`director`) values
    ('$new_id','$title','$image','$released_year','$lang','$runtime','$genre','$overview','$tagline','$cast','$director')";
    mysqli_query($con,$ins_query) or die(mysqli_error($con));
    $msg="New movie with title $title has been created!";
    header("Location: ../View/admin_data_manager.php?table=movie&msg='$msg'");
}else{
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Insert movie</title>
</head>
<body>
    
    <?php
    include ('../View/admin_header.html');
    //print the form containing the value from the query
    echo '<form action="" method="post">';
    echo '<input type="hidden" name="new" value=1>';
    echo '<label for="title">Title:</label><br>';
    echo '<input type="text" id="title" name="title" required><br><br>';

    echo '<label for="image">Image URL:</label><br>';
    echo '<input type="url" id="image" name="image" required><br><br>';

    echo '<label for="released_year">Released Year:</label><br>';
    echo '<input type="number" id="released_year" name="released_year" min="1900" max="2099" step="1" required><br><br>';

    echo '<label for="language">Language:</label><br>';
    echo '<input type="text" id="language" name="language" required><br><br>';

    echo '<label for="runtime">Runtime (minutes):</label><br>';
    echo '<input type="number" id="runtime" name="runtime" min="1" required><br><br>';

    echo '<label for="genre">Genre:</label><br>';
    echo '<input type="text" id="genre" name="genre" required><br><br>';

    echo '<label for="overview">Overview:</label><br>';
    echo '<textarea id="overview" name="overview" rows="4" cols="50" required></textarea><br><br>';

    echo '<label for="tagline">Tagline:</label><br>';
    echo '<input type="text" id="tagline" name="tagline" required><br><br>';

    echo '<label for="cast">Cast:</label><br>';
    echo '<textarea id="cast" name="cast" rows="4" cols="50" required></textarea><br><br>';

    echo '<label for="director">Director:</label><br>';
    echo '<input type="text" id="director" name="director" required><br><br>';  
    echo '<p><input name="submit" type="submit" value="Insert" /></p>';
    echo '</form>';
}
    ?>
</body>
</html>