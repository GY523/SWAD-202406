<?php
include('../Controller/auth.php');
require('../Model/database.php');
//retrieve movie_id from the form
$movie_id=$_GET['movie_id'];

//query database with the id being passed
$sel_query= "SELECT * FROM movie WHERE movie_id='$movie_id';";
$result= mysqli_query($con,$sel_query);
$num_row=mysqli_num_rows($result);
if($num_row==1){
	$row = mysqli_fetch_assoc($result);
	$movie_id= $row['movie_id'];
	$title= $row['title'];
	$image= $row['image'];
	$year= $row['released_year'];
	$lang= $row['language'];
	$runtime=$row['runtime'];
	$genre = $row['genre'];
	$overview= $row['overview'];
	$tagline= $row['tagline'];
	$cast = str_replace("'",'"',$row['cast']);
	$cast = json_decode($cast);
	$cast = join(", ",$cast);
	$director= $row['director'];

}else{
	echo "Duplicate records";
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		
		<title>Movie Review | Single</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">
		
		<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

	</head>


	<body>
		<div id="site-content">
			<?php
			include ('../View/header.html');
			?>

			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span><?php echo $title?></span>
						</div>

						<div class="content">
							<div class="row">
								<div class="col-md-4">
									<figure class="movie-poster"><img src="<?php echo $image; ?>" alt="#"></figure>
								</div>
								<div class="col-md-8">
									<h2 class="movie-title"><?php echo $title ?></h2>
									<div class="movie-summary">
										<?php 
										echo "<p>". $overview ."</p>";
										?>
									</div>
									<ul class="movie-meta">
										<li><strong>Rating:</strong> 
											<?php 
											$sql = "SELECT AVG(rating) as avg_rating, COUNT(rating) as rating_count FROM rate_and_review WHERE movie_id='$movie_id'";
											$result = mysqli_query($con, $sql);
											if (mysqli_num_rows($result) > 0) {
												$row = mysqli_fetch_assoc($result);
        										$ratingMessage = round($row['avg_rating'], 2) . "/5</li>";
											}else{
												$ratingMessage = "No ratings found for the specified movie.";
											}
											echo $ratingMessage;
											?>
										</li>
										<li><strong>Runtime:</strong><?php echo intdiv($runtime,60). "h". $runtime%60 . "m"; ?></li>
										<li><strong>Released year:</strong> <?php echo $year ?></li>
										<li><strong>Language:</strong> <?php echo strtoupper($lang) ?></li>
										<li><strong>Genre:</strong> <?php echo $genre ?></li>
									</ul>

									<ul class="starring">
										<li><strong>Directors:</strong> <?php echo $director ?></li>
										<li><strong>Cast:</strong> <?php echo $cast ?></li>
									</ul>
								</div>
								
							</div> <!-- .row -->
							<div class="col-md-12">
									<h2><a href="../Controller/review.php?movie_id=<?php echo $movie_id; ?>">Review</a></h2><br>
									<h2><a href="../Controller/rate2.php?movie_id=<?php echo $movie_id; ?>">Rate</a></h2>
									
							</div>
							<?php include('../Controller/show_rev.php'); ?>
							
						</div>
					</div>
				</div> <!-- .container -->
				

			</main>
			
			<?php
			include ('../View/footer.html');
			?>
		</div>
		<!-- Default snippet for navigation -->
		


		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		
	</body>

</html>