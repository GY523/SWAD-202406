<?php
include('../Controller/auth.php');
require('../Model/database.php');

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		
		<title>Movie Review</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">
		
		<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

	</head>
    <body>
		

		<div id="site-content">
			<?php
			include '../View/header.html';
			?>
			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Movie Review</span>
						</div>
			
						<div class="movie-list">
                            <?php
                                //if page=1; starts from 1 to 16 => no offset || 0*16
                                //page=2; starts from 17 => offset 16 || 1*16
                                //page 3: starts from 33 => offset 32 || 2*16
                                $page=$_GET['page'] ?? 1;
								$movie_per_page= 8;
                                $offset= ($page-1)*$movie_per_page;

                                //retrieve movie_id, image, title, released_year, runtime, tagline
                                $sel_query = "SELECT * FROM movie ORDER BY released_year desc LIMIT $offset,$movie_per_page ;";
                                $result= mysqli_query($con,$sel_query);
                                while($row= mysqli_fetch_assoc($result)){
                                //display it in format of 1st row: image, 2nd row: title(released_year),
                                //3rd row: runtime, 4th : tagline
									$movie_id= $row['movie_id'];
									$title= $row['title'];
									$image= $row['image'];
									$year= $row['released_year'];
									$runtime=$row['runtime'];
									$lang= $row['language'];
									$tagline= $row['tagline'];
                            ?>
							<div class="movie">
								<figure class="movie-poster"><img src=<?php echo $image?> ></figure>
								<div class="movie-title"><a href=<?php echo "'rate_and_review.php?movie_id=". $movie_id."'>". $title. ' ('.$year.')'?></a></div>
								<p><?php echo intdiv($runtime,60). "h". $runtime%60 . "m\t". $lang; ?> </p>
                                <p><?php echo $tagline ?></p>
							</div>
                            <?php 
                            } 
							if(mysqli_num_rows($result)==0) echo "<strong> No more result</strong>";
                            ?>
						</div> <!-- .movie-list -->

						<div class="pagination">
							<a href="index.php<?php 
                            if($page-1<1)  ;
                            else echo "?page=".$page-1; ?>"
                            class="page-number prev"><i class="fa fa-angle-left"></i></a>
							<?php 
							
							?>
							<a href="index.php?page=1" class="page-number">1</a>
							<a href="index.php?page=2" class="page-number">2</a>
							<a href="index.php?page=3" class="page-number">3</a>
							<a href="index.php?page=4" class="page-number">4</a>
							<a href="index.php?page=5" class="page-number">5</a>
							<a href="index.php<?php echo "?page=" .$page+1 ?>" class="page-number next"><i class="fa fa-angle-right"></i></a>
						</div>
					</div>
				</div> <!-- .container -->
			</main>
			<?php
			include ('../View/footer.html');
			?>
		</div>
		<!-- Default snippet for navigation -->
		


		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		
	</body>
</html>