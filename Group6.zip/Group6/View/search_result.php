<?php
include('../Controller/auth.php');
require('../Model/database.php');

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		
		<title>Movie Review</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="../View/style.css">
		
		<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

	</head>
    <body>
		

		<div id="site-content">
			<?php
			include '../View/header.html';
			?>
			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Movie Review</span>
						</div>

                        <div class="movie-list">
                            <?php 
                                //retrieve the value sent by get method
                                $search= $_GET['search'];  
                            ?>
                            <h2>Search result for title containing "<?php echo $search; ?>"</h2>
                            <?php

							//retrieve movie_id, image, title, released_year, runtime, tagline
							$sel_query = "SELECT * FROM movie WHERE title LIKE '%$search%' ORDER BY released_year desc;";
							$result= mysqli_query($con,$sel_query);
							while($row= mysqli_fetch_assoc($result)){
							//display it in format of 1st row: image, 2nd row: title(released_year),
							//3rd row: runtime, 4th : tagline
								$movie_id= $row['movie_id'];
								$title= $row['title'];
								$image= $row['image'];
								$year= $row['released_year'];
								$runtime=$row['runtime'];
								$lang= $row['language'];
								$tagline= $row['tagline'];
                            ?>
							<div class="movie">
								<figure class="movie-poster"><img src=<?php echo $image?> ></figure>
								<div class="movie-title"><a href=<?php echo "'rate_and_review.php?movie_id=". $movie_id."'>". $title. ' ('.$year.')'?></a></div>
								<p><?php echo intdiv($runtime,60). "h". $runtime%60 . "m\t". $lang; ?> </p>
                                <p><?php echo $tagline ?></p>
							</div>
                            <?php 
                            } 
							if(mysqli_num_rows($result)==0) echo "<strong> No more result</strong>";
                            ?>
						</div> <!-- .movie-list -->

					</div>
				</div> <!-- .container -->
			</main>
			<?php 
			include ('../View/footer.html');
			?>
		</div>
		<!-- Default snippet for navigation -->
		


		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
		
	</body>
</html>