<?php
include('../Controller/auth.php');
require('../Model/database.php');


$user_id = $_SESSION['user_id'];

// get user's information and show in the profile page
$query = "SELECT * FROM user WHERE user_id='$user_id'";
$result = mysqli_query($con, $query);
$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="refresh" content="60">
    <link rel="stylesheet" href="style.css">
    <title>User Profile</title>

</head>
<body>
    <?php 
    include('../View/header.html');
    ?>
    <div id="site-content">
        <main class="main-content">
            <div class="container">
                <h2>User Profile</h2>
                <hr>
                <strong>
                    <p>Username: <?php echo htmlspecialchars($user['user_name']); ?></p>
                    <p>Email: <?php echo htmlspecialchars($user['user_email']); ?></p>
                    <p>Age: <?php echo htmlspecialchars($user['user_age']); ?></p>
                    <p>Country: <?php echo htmlspecialchars($user['user_country']); ?></p>
                    <p></p>
                    <p><a href="../Controller/edit_user_form.php">Update User Information</a></p>
                    <p><a href="../Controller/logout.php">Logout</a></p>
                    <a href="../Controller/delete_user.php?<?php echo "user_id=". $_SESSION['user_id']; ?>">Delete account</a>
                </strong>
            </div>
            <div class="container">
                <hr><hr>
                <h2>Reviewed Movie</h2>
                <hr><hr>
                <?php include('../Controller/show_user_rev.php');?>
            </div>
                
        </main>
    </div>
    <?php 
    include('../View/footer.html');
    ?>

</body>
</html>