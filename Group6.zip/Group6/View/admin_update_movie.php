<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin-Update movie</title>
</head>
<body>
<?php
include('../Controller/admin_auth.php');
require('../Model/database.php');

$table_name= 'movie';
//retrieve movie id from the url
$movie_id=$_GET['movie_id'];

//query for field of specific movie with movie_id
$sel_query="SELECT * FROM movie WHERE 
movie_id = '$movie_id';";
$result = mysqli_query($con,$sel_query) or die(mysqli_error($con));
$row= mysqli_fetch_assoc($result);

//assign each field value a variable
$title = $row['title'];
$image= $row['image'];
$released_year=$row['released_year'];
$lang= $row['language'];
$runtime=$row['runtime'];
$genre= $row['genre'];
$overview= addslashes($row['overview']);
$tagline= addslashes($row['tagline']);
$cast = addslashes($row['cast']);
$director= addslashes($row['director']);

if(isset($_POST['new']) && $_POST['new']==1){
    //operation for updating a specific movie's details contained in the form
    $title = $_POST['title'];
    $image= $_POST['image'];
    $released_year=$_POST['released_year'];
    $lang= $_POST['language'];
    $runtime=$_POST['runtime'];
    $genre= $_POST['genre'];
    $overview= addslashes($_POST['overview']);
    $tagline= addslashes($_POST['tagline']);
    $cast = addslashes($_POST['cast']);
    $director= addslashes($_POST['director']);

    $upd_query=" UPDATE $table_name SET title = '$title', image = '$image',
    released_year = '$released_year', language = '$lang', runtime = '$runtime',
    genre = '$genre', overview = '$overview', tagline = '$tagline',
    cast = '$cast', director = '$director'
    WHERE movie_id = '$movie_id';";
    mysqli_query($con,$upd_query) or die(mysqli_error($con));
    $msg= "Movie with title $title has been updated!";
    header("Location: admin_data_manager.php?table=movie&msg='$msg'");
}else{
    
    //print the form containing the value from the query
    echo '<form action="" method="post">';
    echo '<input type="hidden" name="new" value=1>';
    echo '<label for="title">Title:</label><br>';
    echo '<input type="text" id="title" name="title" value="'.$title.'" required><br><br>';

    echo '<label for="image">Image URL:</label><br>';
    echo '<input type="url" id="image" name="image" value="'.$image.'" required><br><br>';

    echo '<label for="released_year">Released Year:</label><br>';
    echo '<input type="number" id="released_year" name="released_year" value="'.$released_year.'" min="1900" max="2099" step="1" required><br><br>';

    echo '<label for="language">Language:</label><br>';
    echo '<input type="text" id="language" name="language" value="'.$lang.'" required><br><br>';

    echo '<label for="runtime">Runtime (minutes):</label><br>';
    echo '<input type="number" id="runtime" name="runtime" value="'.$runtime.'" min="1" required><br><br>';

    echo '<label for="genre">Genre:</label><br>';
    echo '<input type="text" id="genre" name="genre" value="'.$genre.'" required><br><br>';

    echo '<label for="overview">Overview:</label><br>';
    echo '<textarea id="overview" name="overview" rows="4" cols="50" required>'.htmlspecialchars($overview).'</textarea><br><br>';

    echo '<label for="tagline">Tagline:</label><br>';
    echo '<input type="text" id="tagline" name="tagline" value="'.htmlspecialchars($tagline).'" required><br><br>';

    echo '<label for="cast">Cast:</label><br>';
    echo '<textarea id="cast" name="cast" rows="4" cols="50" required>'.htmlspecialchars($cast).'</textarea><br><br>';

    echo '<label for="director">Director:</label><br>';
    echo '<input type="text" id="director" name="director" value="'.htmlspecialchars($director).'" required><br><br>';  
    echo '<p><input name="submit" type="submit" value="Update" /></p>';
    echo '</form>';
}
?>

</body>
</html>