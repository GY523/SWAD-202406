-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2024 at 07:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `movie_id` varchar(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` tinytext NOT NULL,
  `released_year` int(11) NOT NULL,
  `language` char(2) NOT NULL,
  `runtime` int(11) NOT NULL,
  `genre` tinytext NOT NULL,
  `overview` text NOT NULL,
  `tagline` tinytext NOT NULL,
  `cast` text NOT NULL,
  `director` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`movie_id`, `title`, `image`, `released_year`, `language`, `runtime`, `genre`, `overview`, `tagline`, `cast`, `director`) VALUES
('tt0109830', 'Forrest Gump', 'https://m.media-amazon.com/images/M/MV5BNWIwODRlZTUtY2U3ZS00Yzg1LWJhNzYtMmZiYmEyNmU1NjMzXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_QL75_UY562_CR4,0,380,562_.jpg', 1994, 'en', 142, 'Comedy, Drama, Romance', 'A man with a low IQ has accomplished great things in his life and been present during significant historic events—in each case, far exceeding what anyone imagined he could do. But despite all he has achieved, his one true love eludes him.', 'The world will never be the same once you\'ve seen it through the eyes of Forrest Gump.', '[\'Tom Hanks\', \'Robin Wright\', \'Gary Sinise\', \'Sally Field\']', 'Robert Zemeckis'),
('tt0110912', 'Pulp Fiction', 'https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTUtNTBlZi00MTRlLWFjM2ItYzViMjE3YzI5MjljXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_QL75_UY562_CR3,0,380,562_.jpg', 1994, 'en', 154, 'Thriller, Crime', 'A burger-loving hit man, his philosophical partner, a drug-addled gangster\'s moll and a washed-up boxer converge in this sprawling, comedic crime caper. Their adventures unfurl in three stories that ingeniously trip back and forth in time.', 'You won\'t know the facts until you\'ve seen the fiction.', '[\'John Travolta\', \'Uma Thurman\', \'Samuel L. Jackson\', \'Bruce Willis\']', 'Quentin Tarantino'),
('tt0111161', 'The Shawshank Redemption', 'https://m.media-amazon.com/images/M/MV5BMDFkYTc0MGEtZmNhMC00ZDIzLWFmNTEtODM1ZmRlYWMwMWFmXkEyXkFqcGdeQXVyMTMxODk2OTU@', 1994, 'en', 142, 'Drama, Crime', 'Imprisoned in the 1940s for the double murder of his wife and her lover, upstanding banker Andy Dufresne begins a new life at the Shawshank prison, where he puts his accounting skills to work for an amoral warden. During his long stretch in prison, Dufresne comes to be admired by the other inmates -- including an older prisoner named Red -- for his integrity and unquenchable sense of hope.', 'Fear can hold you prisoner. Hope can set you free.', '[\'Tim Robbins\', \'Morgan Freeman\', \'Bob Gunton\', \'William Sadler\']', 'Frank Darabont'),
('tt0112573', 'Braveheart', 'https://m.media-amazon.com/images/M/MV5BMzkzMmU0YTYtOWM3My00YzBmLWI0YzctOGYyNTkwMWE5MTJkXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_QL75_UY562_CR1,0,380,562_.jpg', 1995, 'en', 177, 'Action, Drama, History, War', 'Enraged at the slaughter of Murron, his new bride and childhood love, Scottish warrior William Wallace slays a platoon of the local English lord\'s soldiers. This leads the village to revolt and, eventually, the entire country to rise up against English rule.', 'Every man dies, not every man truly lives.', '[\'Mel Gibson\', \'Sophie Marceau\', \'Patrick McGoohan\', \'Angus Macfadyen\']', 'Mel Gibson'),
('tt0114369', 'Se7en', 'https://m.media-amazon.com/images/M/MV5BOTUwODM5MTctZjczMi00OTk4LTg3NWUtNmVhMTAzNTNjYjcyXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,16,380,562_.jpg', 1995, 'en', 127, 'Crime, Mystery, Thriller', 'Two homicide detectives are on a desperate hunt for a serial killer whose crimes are based on the \"seven deadly sins\" in this dark and haunting film that takes viewers from the tortured remains of one victim to the next. The seasoned Det. Sommerset researches each sin in an effort to get inside the killer\'s mind, while his novice partner, Mills, scoffs at his efforts to unravel the case.', 'Seven deadly sins. Seven ways to die.', '[\'Morgan Freeman\', \'Brad Pitt\', \'Kevin Spacey\', \'Andrew Kevin Walker\']', 'David Fincher'),
('tt0114709', 'Toy Story', 'https://m.media-amazon.com/images/M/MV5BMDU2ZWJlMjktMTRhMy00ZTA5LWEzNDgtYmNmZTEwZTViZWJkXkEyXkFqcGdeQXVyNDQ2OTk4MzI@._V1_QL75_UX380_CR0,2,380,562_.jpg', 1995, 'en', 81, 'Animation, Adventure, Family, Comedy', 'Led by Woody, Andy\'s toys live happily in his room until Andy\'s birthday brings Buzz Lightyear onto the scene. Afraid of losing his place in Andy\'s heart, Woody plots against Buzz. But when circumstances separate Buzz and Woody from their owner, the duo eventually learns to put aside their differences.', 'Hang on for the comedy that goes to infinity and beyond!', '[\'Tom Hanks\', \'Tim Allen\', \'Don Rickles\', \'Jim Varney\']', 'John Lasseter'),
('tt0114814', 'The Usual Suspects', 'https://m.media-amazon.com/images/M/MV5BYTViNjMyNmUtNDFkNC00ZDRlLThmMDUtZDU2YWE4NGI2ZjVmXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,2,380,562_.jpg', 1995, 'en', 106, 'Drama, Crime, Thriller', 'Held in an L.A. interrogation room, Verbal Kint attempts to convince the feds that a mythic crime lord, Keyser Soze, not only exists, but was also responsible for drawing him and his four partners into a multi-million dollar heist that ended with an explosion in San Pedro harbor – leaving few survivors. Verbal lures his interrogators with an incredible story of the crime lord\'s almost supernatural prowess.', 'Five criminals. One line up. No coincidence.', '[\'Kevin Spacey\', \'Gabriel Byrne\', \'Chazz Palminteri\', \'Stephen Baldwin\']', 'Bryan Singer'),
('tt0118799', 'Life Is Beautiful', 'https://m.media-amazon.com/images/M/MV5BYmJmM2Q4NmMtYThmNC00ZjRlLWEyZmItZTIwOTBlZDQ3NTQ1XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_QL75_UX380_CR0,2,380,562_.jpg', 1997, 'it', 116, 'Comedy, Drama', 'A touching story of an Italian book seller of Jewish ancestry who lives in his own little fairy tale. His creative and happy life would come to an abrupt halt when his entire family is deported to a concentration camp during World War II. While locked up he tries to convince his son that the whole thing is just a game.', 'An unforgettable fable that proves love, family and imagination conquer all.', '[\'Roberto Benigni\', \'Nicoletta Braschi\', \'Giorgio Cantarini\', \'Giustino Durano\']', 'Roberto Benigni'),
('tt0119217', 'Good Will Hunting', 'https://m.media-amazon.com/images/M/MV5BOTI0MzcxMTYtZDVkMy00NjY1LTgyMTYtZmUxN2M3NmQ2NWJhXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_QL75_UX380_CR0,9,380,562_.jpg', 1997, 'en', 127, 'Drama', 'When professors discover that an aimless janitor is also a math genius, a therapist helps the young man confront the demons that are holding him back.', 'Some people can never believe in themselves, until someone believes in them.', '[\'Robin Williams\', \'Matt Damon\', \'Ben Affleck\', \'Stellan Skarsgård\']', 'Gus Van Sant'),
('tt0119698', 'Princess Mononoke', 'https://m.media-amazon.com/images/M/MV5BNGIzY2IzODQtNThmMi00ZDE4LWI5YzAtNzNlZTM1ZjYyYjUyXkEyXkFqcGdeQXVyODEzNjM5OTQ@._V1_QL75_UX380_CR0,4,380,562_.jpg', 1997, 'ja', 134, 'Adventure, Fantasy, Animation', 'Ashitaka, a prince of the disappearing Emishi people, is cursed by a demonized boar god and must journey to the west to find a cure. Along the way, he encounters San, a young human woman fighting to protect the forest, and Lady Eboshi, who is trying to destroy it. Ashitaka must find a way to bring balance to this conflict.', 'The fate of the world rests on the courage of one warrior.', '[\'Yôji Matsuda\', \'Yuriko Ishida\', \'Yûko Tanaka\', \'Billy Crudup\']', 'Hayao Miyazaki'),
('tt0120586', 'American History X', 'https://m.media-amazon.com/images/M/MV5BZTJhN2FkYWEtMGI0My00YWM4LWI2MjAtM2UwNjY4MTI2ZTQyXkEyXkFqcGdeQXVyNjc3MjQzNTI@', 2000, 'en', 119, 'Drama', 'Derek Vineyard is paroled after serving 3 years in prison for killing two African-American men. Through his brother, Danny Vineyard\'s narration, we learn that before going to prison, Derek was a skinhead and the leader of a violent white supremacist gang that committed acts of racial crime throughout L.A. and his actions greatly influenced Danny. Reformed and fresh out of prison, Derek severs contact with the gang and becomes determined to keep Danny from going down the same violent path as he did.', 'Some Legacies Must End.', '[\'Edward Norton\', \'Edward Furlong\', \"Beverly D\'Angelo\", \'Jennifer Lien\']', 'Tony Kaye'),
('tt0120689', 'The Green Mile', 'https://m.media-amazon.com/images/M/MV5BMTUxMzQyNjA5MF5BMl5BanBnXkFtZTYwOTU2NTY3._V1_QL75_UX380_CR0,0,380,562_.jpg', 1999, 'en', 189, 'Fantasy, Drama, Crime', 'A supernatural tale set on death row in a Southern prison, where gentle giant John Coffey possesses the mysterious power to heal people\'s ailments. When the cell block\'s head guard, Paul Edgecomb, recognizes Coffey\'s miraculous gift, he tries desperately to help stave off the condemned man\'s execution.', 'Paul Edgecomb didn\'t believe in miracles. Until the day he met one.', '[\'Tom Hanks\', \'Michael Clarke Duncan\', \'David Morse\', \'Bonnie Hunt\']', 'Frank Darabont'),
('tt0120737', 'The Lord of the Rings: The Fellowship of the Ring', 'https://m.media-amazon.com/images/M/MV5BN2EyZjM3NzUtNWUzMi00MTgxLWI0NTctMzY4M2VlOTdjZWRiXkEyXkFqcGdeQXVyNDUzOTQ5MjY@', 2001, 'en', 179, 'Adventure, Fantasy, Action', 'Young hobbit Frodo Baggins, after inheriting a mysterious ring from his uncle Bilbo, must leave his home in order to keep it from falling into the hands of its evil creator. Along the way, a fellowship is formed to protect the ringbearer and make sure that the ring arrives at its final destination: Mt. Doom, the only place where it can be destroyed.', 'One ring to rule them all.', '[\'Elijah Wood\', \'Ian McKellen\', \'Orlando Bloom\', \'Sean Bean\']', 'Peter Jackson'),
('tt0120815', 'Saving Private Ryan', 'https://m.media-amazon.com/images/M/MV5BZjhkMDM4MWItZTVjOC00ZDRhLThmYTAtM2I5NzBmNmNlMzI1XkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_QL75_UY562_CR1,0,380,562_.jpg', 1998, 'en', 169, 'Drama, History, War', 'As U.S. troops storm the beaches of Normandy, three brothers lie dead on the battlefield, with a fourth trapped behind enemy lines. Ranger captain John Miller and seven men are tasked with penetrating German-held territory and bringing the boy home.', 'The mission is a man.', '[\'Tom Hanks\', \'Matt Damon\', \'Tom Sizemore\', \'Edward Burns\']', 'Steven Spielberg'),
('tt0133093', 'The Matrix', 'https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,4,380,562_.jpg', 1999, 'en', 136, 'Action, Science Fiction', 'Set in the 22nd century, The Matrix tells the story of a computer hacker who joins a group of underground insurgents fighting the vast and powerful computers who now rule the earth.', 'Believe the unbelievable.', '[\'Keanu Reeves\', \'Laurence Fishburne\', \'Carrie-Anne Moss\', \'Hugo Weaving\']', 'Lilly Wachowski, Lana Wachowski'),
('tt0137523', 'Fight Club', 'https://m.media-amazon.com/images/M/MV5BNDIzNDU0YzEtYzE5Ni00ZjlkLTk5ZjgtNjM3NWE4YzA3Nzk3XkEyXkFqcGdeQXVyMjUzOTY1NTc@', 1999, 'en', 139, 'Drama', 'A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground \"fight clubs\" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.', 'Mischief. Mayhem. Soap.', '[\'Brad Pitt\', \'Edward Norton\', \'Meat Loaf\', \'Zach Grenier\']', 'David Fincher'),
('tt0167260', 'The Lord of the Rings: The Return of the King', 'https://m.media-amazon.com/images/M/MV5BNzA5ZDNlZWMtM2NhNS00NDJjLTk4NDItYTRmY2EwMWZlMTY3XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2003, 'en', 201, 'Adventure, Fantasy, Action', 'As armies mass for a final battle that will decide the fate of the world--and powerful, ancient forces of Light and Dark compete to determine the outcome--one member of the Fellowship of the Ring is revealed as the noble heir to the throne of the Kings of Men. Yet, the sole hope for triumph over evil lies with a brave hobbit, Frodo, who, accompanied by his loyal friend Sam and the hideous, wretched Gollum, ventures deep into the very dark heart of Mordor on his seemingly impossible quest to destroy the Ring of Power.​', 'There can be no triumph without loss. No victory without suffering. No freedom without sacrifice.', '[\'Elijah Wood\', \'Viggo Mortensen\', \'Ian McKellen\', \'Orlando Bloom\']', 'Peter Jackson'),
('tt0167261', 'The Lord of the Rings: The Two Towers', 'https://m.media-amazon.com/images/M/MV5BZGMxZTdjZmYtMmE2Ni00ZTdkLWI5NTgtNjlmMjBiNzU2MmI5XkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,14,380,562_.jpg', 2002, 'en', 179, 'Adventure, Fantasy, Action', 'Frodo Baggins and the other members of the Fellowship continue on their sacred quest to destroy the One Ring--but on separate paths. Their destinies lie at two towers--Orthanc Tower in Isengard, where the corrupt wizard Saruman awaits, and Sauron\'s fortress at Barad-dur, deep within the dark lands of Mordor. Frodo and Sam are trekking to Mordor to destroy the One Ring of Power while Gimli, Legolas and Aragorn search for the orc-captured Merry and Pippin. All along, nefarious wizard Saruman awaits the Fellowship members at the Orthanc Tower in Isengard.', 'The fellowship is broken. The power of darkness grows...', '[\'Elijah Wood\', \'Ian McKellen\', \'Viggo Mortensen\', \'Orlando Bloom\']', 'Peter Jackson'),
('tt0169547', 'American Beauty', 'https://m.media-amazon.com/images/M/MV5BNTBmZWJkNjctNDhiNC00MGE2LWEwOTctZTk5OGVhMWMyNmVhXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_QL75_UX380_CR0,0,380,562_.jpg', 1999, 'en', 122, 'Drama', 'Lester Burnham, a depressed suburban father in a mid-life crisis, decides to turn his hectic life around after developing an infatuation with his daughter\'s attractive friend.', 'Look closer.', '[\'Kevin Spacey\', \'Annette Bening\', \'Thora Birch\', \'Wes Bentley\']', 'Sam Mendes'),
('tt0172495', 'Gladiator', 'https://m.media-amazon.com/images/M/MV5BMDliMmNhNDEtODUyOS00MjNlLTgxODEtN2U3NzIxMGVkZTA1L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,0,380,562_.jpg', 1994, 'en', 155, 'Action, Drama, Adventure', 'In the year 180, the death of emperor Marcus Aurelius throws the Roman Empire into chaos.  Maximus is one of the Roman army\'s most capable and trusted generals and a key advisor to the emperor.  As Marcus\' devious son Commodus ascends to the throne, Maximus is set to be executed.  He escapes, but is captured by slave traders.  Renamed Spaniard and forced to become a gladiator, Maximus must battle to the death with other men for the amusement of paying audiences.', 'What we do in life echoes in eternity.', '[\'Russell Crowe\', \'Joaquin Phoenix\', \'Connie Nielsen\', \'Oliver Reed\']', 'Ridley Scott'),
('tt0180093', 'Requiem for a Dream', 'https://m.media-amazon.com/images/M/MV5BOTdiNzJlOWUtNWMwNS00NmFlLWI0YTEtZmI3YjIzZWUyY2Y3XkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UX380_CR0,4,380,562_.jpg', 2000, 'en', 102, 'Crime, Drama', 'The drug-induced utopias of four Coney Island residents are shattered when their addictions run deep.', '', '[\'Ellen Burstyn\', \'Jared Leto\', \'Jennifer Connelly\', \'Marlon Wayans\']', 'Darren Aronofsky'),
('tt0209144', 'Memento', 'https://m.media-amazon.com/images/M/MV5BZTcyNjk1MjgtOWI3Mi00YzQwLWI5MTktMzY4ZmI2NDAyNzYzXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UY562_CR2,0,380,562_.jpg', 2000, 'en', 113, 'Mystery, Thriller', 'Leonard Shelby is tracking down the man who raped and murdered his wife. The difficulty of locating his wife\'s killer, however, is compounded by the fact that he suffers from a rare, untreatable form of short-term memory loss. Although he can recall details of life before his accident, Leonard cannot remember what happened fifteen minutes ago, where he\'s going, or why.', 'Some memories are best forgotten.', '[\'Guy Pearce\', \'Carrie-Anne Moss\', \'Joe Pantoliano\', \'Mark Boone Junior\']', 'Christopher Nolan'),
('tt0245429', 'Spirited Away', 'https://m.media-amazon.com/images/M/MV5BMjlmZmI5MDctNDE2YS00YWE0LWE5ZWItZDBhYWQ0NTcxNWRhXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2001, 'ja', 125, 'Animation, Family, Fantasy', 'A young girl, Chihiro, becomes trapped in a strange new world of spirits. When her parents undergo a mysterious transformation, she must call upon the courage she never knew she had to free her family.', '', '[\'Daveigh Chase\', \'Suzanne Pleshette\', \'Miyu Irino\', \'Rumi Hiiragi\']', 'Hayao Miyazaki'),
('tt0253474', 'The Pianist', 'https://m.media-amazon.com/images/M/MV5BOWRiZDIxZjktMTA1NC00MDQ2LWEzMjUtMTliZmY3NjQ3ODJiXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UY562_CR14,0,380,562_.jpg', 2002, 'en', 150, 'Drama, War', 'The true story of pianist Władysław Szpilman\'s experiences in Warsaw during the Nazi occupation. When the Jews of the city find themselves forced into a ghetto, Szpilman finds work playing in a café; and when his family is deported in 1942, he stays behind, works for a while as a laborer, and eventually goes into hiding in the ruins of the war-torn city.', 'Music was his passion. Survival was his masterpiece.', '[\'Adrien Brody\', \'Thomas Kretschmann\', \'Frank Finlay\', \'Emilia Fox\']', 'Roman Polanski'),
('tt0317248', 'City of God', 'https://m.media-amazon.com/images/M/MV5BOTMwYjc5ZmItYTFjZC00ZGQ3LTlkNTMtMjZiNTZlMWQzNzI5XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_QL75_UX380_CR0,2,380,562_.jpg', 2002, 'pt', 130, 'Drama, Crime', 'In the slums of Rio, two kids\' paths diverge as one struggles to become a photographer and the other a kingpin.', 'If you run, the beast catches you; if you stay, the beast eats you.', '[\'Alexandre Rodrigues\', \'Leandro Firmino\', \'Matheus Nachtergaele\', \'Phellipe Haagensen\']', 'Fernando Meirelles'),
('tt0338013', 'Eternal Sunshine of the Spotless Mind', 'https://m.media-amazon.com/images/M/MV5BMTY4NzcwODg3Nl5BMl5BanBnXkFtZTcwNTEwOTMyMw@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2004, 'en', 108, 'Science Fiction, Drama, Romance', 'Joel Barish, heartbroken that his girlfriend underwent a procedure to erase him from her memory, decides to do the same. However, as he watches his memories of her fade away, he realises that he still loves her, and may be too late to correct his mistake.', 'You can erase someone from your mind. Getting them out of your heart is another story.', '[\'Jim Carrey\', \'Kate Winslet\', \'Tom Wilkinson\', \'Gerry Robert Byrne\']', 'Michel Gondry'),
('tt0361748', 'Inglourious Basterds', 'https://m.media-amazon.com/images/M/MV5BOTJiNDEzOWYtMTVjOC00ZjlmLWE0NGMtZmE1OWVmZDQ2OWJhXkEyXkFqcGdeQXVyNTIzOTk5ODM@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2009, 'en', 153, 'Drama, Thriller, War', 'In Nazi-occupied France during World War II, a group of Jewish-American soldiers known as \"The Basterds\" are chosen specifically to spread fear throughout the Third Reich by scalping and brutally killing Nazis. The Basterds, lead by Lt. Aldo Raine soon cross paths with a French-Jewish teenage girl who runs a movie theater in Paris which is targeted by the soldiers.', 'A basterd\'s work is never done.', '[\'Brad Pitt\', \'Diane Kruger\', \'Eli Roth\', \'Mélanie Laurent\']', 'Quentin Tarantino'),
('tt0364569', 'Oldboy', 'https://m.media-amazon.com/images/M/MV5BMTI3NTQyMzU5M15BMl5BanBnXkFtZTcwMTM2MjgyMQ@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2003, 'ko', 120, 'Drama, Thriller, Mystery, Action', 'With no clue how he came to be imprisoned, drugged and tortured for 15 years, a desperate man seeks revenge on his captors.', 'Laugh, and the world laughs with you. Weep, and you weep alone.', '[\'Choi Min-sik\', \'Yoo Ji-tae\', \'Kang Hye-jeong\', \'Kim Byeong-Ok\']', 'Park Chan-wook'),
('tt0405094', 'The Lives of Others', 'https://m.media-amazon.com/images/M/MV5BNmQyNmJjM2ItNTQzYi00ZjMxLWFjMDYtZjUyN2YwZDk5YWQ2XkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_QL75_UX380_CR0,3,380,562_.jpg', 2006, 'de', 137, 'Drama, Thriller', 'In 1984 East Berlin, an agent of the secret police, conducting surveillance on a writer and his lover, finds himself becoming increasingly absorbed by their lives.', 'Before the Fall of the Berlin Wall, East Germany\'s Secret Police Listened to Your Secrets.', '[\'Ulrich Mühe\', \'Martina Gedeck\', \'Sebastian Koch\', \'Ulrich Tukur\']', 'Florian Henckel von Donnersmarck'),
('tt0407887', 'The Departed', 'https://m.media-amazon.com/images/M/MV5BMTI1MTY2OTIxNV5BMl5BanBnXkFtZTYwNjQ4NjY3._V1_QL75_UY562_CR0,0,380,562_.jpg', 1998, 'en', 151, 'Drama, Thriller, Crime', 'To take down South Boston\'s Irish Mafia, the police send in one of their own to infiltrate the underworld, not realizing the syndicate has done likewise. While an undercover cop curries favor with the mob kingpin, a career criminal rises through the police ranks. But both sides soon discover there\'s a mole among them.', 'Cops or criminals. When you’re facing a loaded gun, what’s the difference?', '[\'Leonardo DiCaprio\', \'Matt Damon\', \'Jack Nicholson\', \'Mark Wahlberg\']', 'Martin Scorsese'),
('tt0435761', 'Toy Story 3', 'https://m.media-amazon.com/images/M/MV5BMTgxOTY4Mjc0MF5BMl5BanBnXkFtZTcwNTA4MDQyMw@@._V1_QL75_UY562_CR9,0,380,562_.jpg', 2010, 'en', 103, 'Animation, Family, Comedy', 'Woody, Buzz, and the rest of Andy\'s toys haven\'t been played with in years. With Andy about to go to college, the gang find themselves accidentally left at a nefarious day care center. The toys must band together to escape and return home to Andy.', 'No toy gets left behind.', '[\'Tom Hanks\', \'Tim Allen\', \'Joan Cusack\', \'Ned Beatty\']', 'Lee Unkrich'),
('tt0468569', 'The Dark Knight', 'https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2008, 'en', 152, 'Drama, Action, Crime, Thriller', 'Batman raises the stakes in his war on crime. With the help of Lt. Jim Gordon and District Attorney Harvey Dent, Batman sets out to dismantle the remaining criminal organizations that plague the streets. The partnership proves to be effective, but they soon find themselves prey to a reign of chaos unleashed by a rising criminal mastermind known to the terrified citizens of Gotham as the Joker.', 'Welcome to a world without rules.', '[\'Christian Bale\', \'Heath Ledger\', \'Aaron Eckhart\', \'Michael Caine\']', 'Christopher Nolan'),
('tt0482571', 'The Prestige', 'https://m.media-amazon.com/images/M/MV5BMjA4NDI0MTIxNF5BMl5BanBnXkFtZTYwNTM0MzY2._V1_QL75_UX380_CR0,0,380,562_.jpg', 2006, 'en', 130, 'Drama, Mystery, Science Fiction', 'A mysterious story of two magicians whose intense rivalry leads them on a life-long battle for supremacy -- full of obsession, deceit and jealousy with dangerous and deadly consequences.', 'Are You Watching Closely?', '[\'Christian Bale\', \'Hugh Jackman\', \'Scarlett Johansson\', \'Michael Caine\']', 'Christopher Nolan'),
('tt0816692', 'Interstellar', 'https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDktN2IxOS00OGEyLWFmMjktY2FiMmZkNWIyODZiXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2014, 'en', 169, 'Adventure, Drama, Science Fiction', 'The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.', 'Mankind was born on Earth. It was never meant to die here.', '[\'Matthew McConaughey\', \'Anne Hathaway\', \'Jessica Chastain\', \'Mackenzie Foy\']', 'Christopher Nolan'),
('tt1187043', '3 Idiots', 'https://m.media-amazon.com/images/M/MV5BNTkyOGVjMGEtNmQzZi00NzFlLTlhOWQtODYyMDc2ZGJmYzFhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_QL75_UY562_CR5,0,380,562_.jpg', 2009, 'hi', 170, 'Drama, Comedy', 'Rascal. Joker. Dreamer. Genius... You\'ve never met a college student quite like \"Rancho.\" From the moment he arrives at India\'s most prestigious university, Rancho\'s outlandish schemes turn the campus upside down—along with the lives of his two newfound best friends. Together, they make life miserable for \"Virus,\" the school’s uptight and heartless dean. But when Rancho catches the eye of the dean\'s daughter, Virus sets his sights on flunking out the \"3 idiots\" once and for all.', 'Aal Izz Well!', '[\'Aamir Khan\', \'Madhavan\', \'Mona Singh\', \'Sharman Joshi\']', 'Rajkumar Hirani'),
('tt1345836', 'The Dark Knight Rises', 'https://m.media-amazon.com/images/M/MV5BMTk4ODQzNDY3Ml5BMl5BanBnXkFtZTcwODA0NTM4Nw@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2012, 'en', 165, 'Action, Crime, Drama, Thriller', 'Following the death of District Attorney Harvey Dent, Batman assumes responsibility for Dent\'s crimes to protect the late attorney\'s reputation and is subsequently hunted by the Gotham City Police Department. Eight years later, Batman encounters the mysterious Selina Kyle and the villainous Bane, a new terrorist leader who overwhelms Gotham\'s finest. The Dark Knight resurfaces to protect a city that has branded him an enemy.', 'A fire will rise.', '[\'Christian Bale\', \'Tom Hardy\', \'Anne Hathaway\', \'Gary Oldman\']', 'Christopher Nolan'),
('tt1375666', 'Inception', 'https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2010, 'en', 148, 'Action, Science Fiction, Adventure', 'Cobb, a skilled thief who commits corporate espionage by infiltrating the subconscious of his targets is offered a chance to regain his old life as payment for a task considered to be impossible: \"inception\", the implantation of another person\'s idea into a target\'s subconscious.', 'Your mind is the scene of the crime.', '[\'Leonardo DiCaprio\', \'Joseph Gordon-Levitt\', \'Elliot Page\', \'Ken Watanabe\']', 'Christopher Nolan'),
('tt15398776', 'Oppenheimer', 'https://m.media-amazon.com/images/M/MV5BMDBmYTZjNjUtN2M1MS00MTQ2LTk2ODgtNzc2M2QyZGE5NTVjXkEyXkFqcGdeQXVyNzAwMjU2MTY@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2023, 'en', 181, 'Drama, History', 'The story of J. Robert Oppenheimer\'s role in the development of the atomic bomb during World War II.', 'The world forever changes.', '[\'Cillian Murphy\', \'Emily Blunt\', \'Matt Damon\', \'Robert Downey Jr.\']', 'Christopher Nolan'),
('tt1675434', 'The Intouchables', 'https://m.media-amazon.com/images/M/MV5BMTYxNDA3MDQwNl5BMl5BanBnXkFtZTcwNTU4Mzc1Nw@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2011, 'fr', 113, 'Drama, Comedy', 'A true story of two men who should never have met – a quadriplegic aristocrat who was injured in a paragliding accident and a young man from the projects.', 'Sometimes you have to reach into someone else\'s world to find out what\'s missing in your own.', '[\'François Cluzet\', \'Omar Sy\', \'Anne Le Ny\', \'Audrey Fleurot\']', 'Olivier Nakache, Éric Toledano'),
('tt1853728', 'Django Unchained', 'https://m.media-amazon.com/images/M/MV5BMjIyNTQ5NjQ1OV5BMl5BanBnXkFtZTcwODg1MDU4OA@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2012, 'en', 165, 'Drama, Western', 'With the help of a German bounty hunter, a freed slave sets out to rescue his wife from a brutal Mississippi plantation owner.', 'Life, liberty, and the pursuit of vengeance.', '[\'Jamie Foxx\', \'Christoph Waltz\', \'Leonardo DiCaprio\', \'Kerry Washington\']', 'Quentin Tarantino'),
('tt2106476', 'The Hunt', 'https://m.media-amazon.com/images/M/MV5BMTg2NDg3ODg4NF5BMl5BanBnXkFtZTcwNzk3NTc3Nw@@._V1_QL75_UY562_CR7,0,380,562_.jpg', 2012, 'da', 116, 'Drama', 'A teacher lives a lonely life, all the while struggling over his son’s custody. His life slowly gets better as he finds love and receives good news from his son, but his new luck is about to be brutally shattered by an innocent little lie.', 'The lie is spreading.', '[\'Mads Mikkelsen\', \'Thomas Bo Larsen\', \'Annika Wedderkopp\', \'Lasse Fogelstrøm\']', 'Thomas Vinterberg'),
('tt2380307', 'Coco', 'https://m.media-amazon.com/images/M/MV5BYjQ5NjM0Y2YtNjZkNC00ZDhkLWJjMWItN2QyNzFkMDE3ZjAxXkEyXkFqcGdeQXVyODIxMzk5NjA@._V1_QL75_UY562_CR7,0,380,562_.jpg', 2017, 'en', 105, 'Family, Animation, Music, Adventure', 'Despite his family’s baffling generations-old ban on music, Miguel dreams of becoming an accomplished musician like his idol, Ernesto de la Cruz. Desperate to prove his talent, Miguel finds himself in the stunning and colorful Land of the Dead following a mysterious chain of events. Along the way, he meets charming trickster Hector, and together, they set off on an extraordinary journey to unlock the real story behind Miguel\'s family history.', 'The celebration of a lifetime.', '[\'Anthony Gonzalez\', \'Gael García Bernal\', \'Benjamin Bratt\', \'Alanna Ubach\']', 'Lee Unkrich'),
('tt2582802', 'Whiplash', 'https://m.media-amazon.com/images/M/MV5BOTA5NDZlZGUtMjAxOS00YTRkLTkwYmMtYWQ0NWEwZDZiNjEzXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2014, 'en', 107, 'Drama, Music', 'Under the direction of a ruthless instructor, a talented young drummer begins to pursue perfection at any cost, even his humanity.', 'The road to greatness can take you to the edge.', '[\'Miles Teller\', \'J.K. Simmons\', \'Melissa Benoist\', \'Paul Reiser\']', 'Damien Chazelle'),
('tt4154756', 'Avengers: Infinity War', 'https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2018, 'en', 149, 'Adventure, Action, Science Fiction', 'As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.', 'An entire universe. Once and for all.', '[\'Robert Downey Jr.\', \'Chris Hemsworth\', \'Mark Ruffalo\', \'Chris Evans\']', 'Joe Russo, Anthony Russo'),
('tt4154796', 'Avengers: Endgame', 'https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2019, 'en', 181, 'Adventure, Science Fiction, Action', 'After the devastating events of Avengers: Infinity War, the universe is in ruins due to the efforts of the Mad Titan, Thanos. With the help of remaining allies, the Avengers must assemble once more in order to undo Thanos\' actions and restore order to the universe once and for all, no matter what consequences may be in store.', 'Avenge the fallen.', '[\'Robert Downey Jr.\', \'Chris Evans\', \'Mark Ruffalo\', \'Chris Hemsworth\']', 'Joe Russo, Anthony Russo'),
('tt4633694', 'Spider-Man: Into the Spider-Verse', 'https://m.media-amazon.com/images/M/MV5BMjMwNDkxMTgzOF5BMl5BanBnXkFtZTgwNTkwNTQ3NjM@', 2018, 'en', 117, 'Animation, Action, Adventure, Science Fiction', 'Struggling to find his place in the world while juggling school and family, Brooklyn teenager Miles Morales is unexpectedly bitten by a radioactive spider and develops unfathomable powers just like the one and only Spider-Man. While wrestling with the implications of his new abilities, Miles discovers a super collider created by the madman Wilson \"Kingpin\" Fisk, causing others from across the Spider-Verse to be inadvertently transported to his dimension.', 'More than one wears the mask.', '[\'Shameik Moore\', \'Jake Johnson\', \'Hailee Steinfeld\', \'Mahershala Ali\']', 'Peter Ramsey, Rodney Rothman, Bob Persichetti'),
('tt5311514', 'Your Name.', 'https://m.media-amazon.com/images/M/MV5BODRmZDVmNzUtZDA4ZC00NjhkLWI2M2UtN2M0ZDIzNDcxYThjL2ltYWdlXkEyXkFqcGdeQXVyNTk0MzMzODA@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2016, 'ja', 106, 'Animation, Romance, Drama', 'High schoolers Mitsuha and Taki are complete strangers living separate lives. But one night, they suddenly switch places. Mitsuha wakes up in Taki’s body, and he in hers. This bizarre occurrence continues to happen randomly, and the two must adjust their lives around each other.', 'Separated by distance, connected by fate.', '[\'Ryunosuke Kamiki\', \'Mone Kamishiraishi\', \'Ryo Narita\', \'Aoi Yûki\']', 'Makoto Shinkai'),
('tt6751668', 'Parasite', 'https://m.media-amazon.com/images/M/MV5BYWZjMjk3ZTItODQ2ZC00NTY5LWE0ZDYtZTI3MjcwN2Q5NTVkXkEyXkFqcGdeQXVyODk4OTc3MTY@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2019, 'ko', 133, 'Comedy, Thriller, Drama', 'All unemployed, Ki-taek\'s family takes peculiar interest in the wealthy and glamorous Parks for their livelihood until they get entangled in an unexpected incident.', 'Act like you own the place.', '[\'Song Kang-ho\', \'Lee Sun-kyun\', \'Cho Yeo-jeong\', \'Choi Woo-sik\']', 'Bong Joon-ho'),
('tt7286456', 'Joker', 'https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_QL75_UX380_CR0,0,380,562_.jpg', 2019, 'en', 122, 'Crime, Thriller, Drama', 'During the 1980s, a failed stand-up comedian is driven insane and turns to a life of crime and chaos in Gotham City while becoming an infamous psychopathic crime figure.', 'Put on a happy face.', '[\'Joaquin Phoenix\', \'Robert De Niro\', \'Zazie Beetz\', \'Frances Conroy\']', 'Todd Phillips'),
('tt8267604', 'Capernaum', 'https://m.media-amazon.com/images/M/MV5BY2Y3OWNkMTctYzNjYS00NWVkLTg4OWEtY2YxN2I3NDhlYzE0XkEyXkFqcGdeQXVyMTI3ODAyMzE2._V1_QL75_UY562_CR7,0,380,562_.jpg', 2018, 'ar', 126, 'Drama', 'After running away from his negligent parents, committing a violent crime and being sentenced to five years in jail, a hardened, streetwise 12-year-old Lebanese boy sues his parents in protest of the life they have given him.', 'It takes courage to hope.', '[\'Zain Al Rafeea\', \'Yordanos Shiferaw\', \'Boluwatife Treasure Bankole\', \'Kawsar Al Haddad\']', 'Nadine Labaki'),
('tt9362722', 'Spider-Man: Across the Spider-Verse', 'https://m.media-amazon.com/images/M/MV5BMzI0NmVkMjEtYmY4MS00ZDMxLTlkZmEtMzU4MDQxYTMzMjU2XkEyXkFqcGdeQXVyMzQ0MzA0NTM@.._V1_QL75_UX380_CR0,0,380,562_.jpg', 2023, 'en', 140, 'Animation, Action, Adventure, Science Fiction', 'After reuniting with Gwen Stacy, Brooklyn’s full-time, friendly neighborhood Spider-Man is catapulted across the Multiverse, where he encounters the Spider Society, a team of Spider-People charged with protecting the Multiverse’s very existence. But when the heroes clash on how to handle a new threat, Miles finds himself pitted against the other Spiders and must set out on his own to save those he loves most.', 'It\'s how you wear the mask that matters.', '[\'Shameik Moore\', \'Hailee Steinfeld\', \'Brian Tyree Henry\', \'Luna Lauren Velez\']', 'Justin K. Thompson, Kemp Powers, Joaquim Dos Santos');

-- --------------------------------------------------------

--
-- Table structure for table `rate_and_review`
--

CREATE TABLE `rate_and_review` (
  `movie_id` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `rating` int(11) NOT NULL,
  `review_heading` tinytext NOT NULL,
  `review_body` text NOT NULL,
  `has_spoiler` tinyint(1) NOT NULL,
  `helpful` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rate_and_review`
--

INSERT INTO `rate_and_review` (`movie_id`, `user_id`, `date_created`, `rating`, `review_heading`, `review_body`, `has_spoiler`, `helpful`) VALUES
('tt15398776', 5, '0000-00-00', 5, '', '', 0, 0),
('tt15398776', 8, '2024-08-20', 0, 'asd', 'asd', 1, 0),
('tt6751668', 8, '0000-00-00', 0, '', '', 0, 0),
('tt9362722', 5, '2024-08-19', 5, 'good', '', 0, 0),
('tt9362722', 6, '2024-08-13', 0, 'hoho', 'hohoho', 1, 0),
('tt9362722', 7, '2024-08-13', 0, 'hehehe', 'heheheheh', 1, 0),
('tt9362722', 8, '2024-08-19', 5, 'good', 'hahahaha', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_country` varchar(255) NOT NULL,
  `user_age` int(11) NOT NULL,
  `reg_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_country`, `user_age`, `reg_date`) VALUES
(5, 'haha', 'haha@gmail.com', '4e4d6c332b6fe62a63afe56171fd3725', 'malaysia', 18, '2024-08-13 16:07:12.000000'),
(6, 'hoho', 'hoho@gmail.com', '74d181ce69fa53e60fb588719cc404e1', 'malaysia', 18, '2024-08-13 16:54:16.000000'),
(7, 'hehe', 'hehe@gmail.com', '529ca8050a00180790cf88b63468826a', 'malaysia', 18, '2024-08-13 17:00:33.000000'),
(8, 'asd', 'asd@gmail.com', '7815696ecbf1c96e6894b779456d330e', 'malaysia', 12, '2024-08-19 16:04:24.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `rate_and_review`
--
ALTER TABLE `rate_and_review`
  ADD PRIMARY KEY (`movie_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rate_and_review`
--
ALTER TABLE `rate_and_review`
  ADD CONSTRAINT `rate_and_review_ibfk_1` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`movie_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rate_and_review_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
