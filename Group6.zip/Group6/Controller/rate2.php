<?php
// Database Connection
$con = mysqli_connect("localhost", "root", "", "app_db");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
include('../Controller/auth.php');

	// Handle Rating Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    $user_id = $_SESSION['user_id'];
    $movie_id = $_POST['movie_id'];
    $rating = $_POST['rating'];
    
	// Check if the delete button was clicked
    if (isset($_POST['deletePreviousRating'])) {
        // Delete the existing rating for the user and movie
        $sql = "DELETE FROM rate_and_review WHERE user_id='$user_id' AND 	movie_id='$movie_id';";
        if (mysqli_query($con, $sql)) {
            $message = "Rating deleted successfully";
        } else {
            $message = "Error: " . $sql . "<br>" . mysqli_error($con);
        }
    } else {
        // Handle rating submission
        $rating = $_POST['rating'];
    }
    
    // Check if rating already exists
    $check_rating = "SELECT * FROM rate_and_review WHERE user_id='$user_id' AND movie_id='$movie_id'";
    $result = mysqli_query($con, $check_rating);

    if (mysqli_num_rows($result) > 0) {
        $sql = "UPDATE rate_and_review SET rating='$rating' WHERE user_id='$user_id' AND movie_id='$movie_id'";
    } else {
        $sql = "INSERT INTO rate_and_review (movie_id, user_id, rating) VALUES ('$movie_id', '$user_id', '$rating')";
    }

    if (mysqli_query($con, $sql)) {
        $message = "Rating submitted successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . mysqli_error($con);
    }
    header("location: ../View/index.php");
}

// Display Average Rating
$movie_id = isset($_GET['movie_id']) ? $_GET['movie_id'] : '';

if ($movie_id) {
    $sql = "SELECT AVG(rating) as avg_rating, COUNT(rating) as rating_count FROM rate_and_review WHERE movie_id='$movie_id'";
    $result = mysqli_query($con, $sql);

    $sqlTitle = "SELECT title FROM movie WHERE movie_id='$movie_id'";
    $resultTitle = mysqli_query($con, $sqlTitle);

    if (mysqli_num_rows($resultTitle) > 0) {
        $rowTitle = mysqli_fetch_assoc($resultTitle);
        $movieTitle = htmlspecialchars($rowTitle['title']);
    } else {
        $movieTitle = "Unknown Movie";
    }

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $ratingMessage = "Average Rating: " . round($row['avg_rating'], 2) . "/5<br>Number of Ratings: " . $row['rating_count'];
    } else {
        $ratingMessage = "No ratings found for the specified movie.";
    }
} else {
    $movieTitle = "No Movie Selected";
    $ratingMessage = "";
}

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Rating Module</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .rating-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .movie-title {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .average-rating {
            font-size: 18px;
            margin-bottom: 20px;
        }
        .rating-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .rating-stars {
    		display: flex;
    		font-size: 50px;
    		cursor: pointer;
    		margin-bottom: 10px;
	}
        .star {
            color: #ccc;
	    transition: color 0.2s;
        }
        .star.active {
            color: gold;
        }
        .rating-stars input[type="radio"] {
    	display: none;
	}

	.rating-stars label {
    		cursor: pointer;
		color: #ccc;
   	 	font-size: 50px;
    		transition: color 0.2s;
	}

	.rating-stars input[type="radio"]:checked ~ label {
    color: gold;
}

    .rating-stars input[type="radio"]:checked + label {
        color: gold;
    }
        .rating-form button {
            background-color: #28a745;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        .rating-form button:hover {
            background-color: #218838;
        }
    </style>
</head>



<div class="rating-container">
    <h2 class="movie-title"><?php echo $movieTitle; ?></h2>

    <div class="average-rating">
        <?php echo $ratingMessage; ?>
    </div>

    <form method="POST" action="">
        <input type="hidden" name="movie_id" value="<?php echo htmlspecialchars($movie_id); ?>">
        <input type="hidden" name="rating" id="rating-value" value="0">

        <fieldset>
        <legend>Rate this movie:</legend>
        <div class="rating-stars">

            <input type="radio" id="star5" name="rating" value="5">
            <label for="star5" title="5 star">&#9734;</label>

            <input type="radio" id="star4" name="rating" value="4">
            <label for="star4" title="4 stars">&#9734;</label>

            <input type="radio" id="star3" name="rating" value="3">
            <label for="star3" title="3 stars">&#9734;</label>

            <input type="radio" id="star2" name="rating" value="2">
            <label for="star2" title="2 stars">&#9734;</label>

            <input type="radio" id="star1" name="rating" value="1">
            <label for="star1" title="1 stars">&#9734;</label>
        </div>
    </fieldset>


        <button type="submit">Submit Rating</button>
        <button type="submit" name="deletePreviousRating">Delete Rating</button>
    </form>

    <h2><b>5-star Rating: Personal</b></h2>
    <p>★★★★★ Favorite</p>
    <p>☆★★★★ Great</p>
    <p>☆☆★★★ Good</p>
    <p>☆☆☆★★ Disappointing</p>
    <p>☆☆☆☆★ Regrettable</p>
    <p>☆☆☆☆☆ Failure</p>
    
</div>

<script>
    const stars = document.querySelectorAll('.rating-stars label');
    const ratingInputs = document.querySelectorAll('.rating-stars input	[type="radio"]');
    const cancelButton = document.getElementById('cancelButton');
    const commentInput = document.getElementById('comment');
    let selectedRating = 0;

    // Click event: Set the rating based on the star clicked
	stars.forEach((star, index) => {
    star.addEventListener('click', () => {
        ratingInputs[index].checked = true; // Check the corresponding radio 	button
	updateStars(index + 1);
    });

    // Mouseover event: Show a preview of the rating
    star.addEventListener('mouseover', () => {
        updateStars(index + 1);
    });

    // Mouseout event: Restore the previous rating
    star.addEventListener('mouseout', () => {
        const selectedRating = document.querySelector('.rating-stars input[type="radio"]:checked');
        updateStars(selectedRating ? selectedRating.value : 0);
    });
});

// Update the star display based on the rating
const updateStars = (rating) => {
    stars.forEach((s, i) => {
        s.style.color = i < rating ? 'gold' : '#ccc';
    });
};

// cancel rating
cancelButton.addEventListener('click', () => {
    ratingInputs.forEach(input => input.checked = false); // Uncheck all radio buttons
    updateStars(0);
    commentInput.value = '';
});
</body>
</html>