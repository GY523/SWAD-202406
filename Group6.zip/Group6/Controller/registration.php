<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>User Registration</title>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f4f4f4;
    }

    /* make the form container center */
    .form {
        border: 1px solid #ccc;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        box-sizing: border-box;
        text-align: center; /* make the contain align to center */
    }

    .form h1 {
        margin-top: 0;
    }

    .form input[type="text"],
    .form input[type="email"],
    .form input[type="password"],
    .form input[type="number"],
    .form input[type="submit"] {
        width: 100%; 
        padding: 10px;
        margin: 8px 0;
        box-sizing: border-box;
    }

    .form input[type="submit"] {
        box-sizing: border-box;
        background-color: #007AFF;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .form p {
        margin: 10px 0;
    }

    .form a {
        display: block;
        margin-top: 10px;
    }
</style>
</head>
<body>
<?php

require('../Model/database.php');

if (isset($_REQUEST['username'])){
$username = stripslashes($_REQUEST['username']);
$username = mysqli_real_escape_string($con,$username); 
$email = stripslashes($_REQUEST['email']);
$email = mysqli_real_escape_string($con,$email);
$password = stripslashes($_REQUEST['password']);
$password = mysqli_real_escape_string($con,$password);
$reg_date = date("Y-m-d H:i:s");
// $gender = stripslashes($_REQUEST['gender']);
// $gender = mysqli_real_escape_string($con, $gender);
$age = stripslashes($_REQUEST['age']);
$age = mysqli_real_escape_string($con, $age);
$country = stripslashes($_REQUEST['country']);
$country = mysqli_real_escape_string($con, $country);
 $query = "INSERT INTO user (user_name, user_password, user_email, reg_date, user_age, user_country)
            VALUES ('$username', '".md5($password)."', '$email', '$reg_date', '$age', '$country')";

 $result = mysqli_query($con,$query);

 if ($result) {
    echo "<script>
            alert('You are registered successfully.');
            window.location.href = 'login.php'; // Redirect to login page
          </script>";
} else {
    echo "<script>
            alert('There was an error registering your account.');
            window.location.href = 'registration.php'; // Redirect back to registration form
          </script>";
}
} else {
?>

<div class="form">
<h1>User Registration</h1>
<form name="registration" action="" method="post">
<input type="text" name="username" placeholder="Username" required /><br>
<input type="email" name="email" placeholder="Email" required /><br>
<input type="password" name="password" placeholder="Password" required /><br>
<input type="number" name="age" placeholder="Age" required /><br>
<input type="text" name="country" placeholder="Country" required /><br>
<input type="submit" name="submit" value="Register" />
</form>
</div>
<?php } ?>
</body>
</html>