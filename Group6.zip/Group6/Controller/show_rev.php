<?php
$query = "
    SELECT r.user_id, u.user_name, r.review_heading, r.review_body, r.date_created 
    FROM rate_and_review r
    JOIN user u ON r.user_id = u.user_id
    WHERE r.movie_id = '$movie_id'
    ORDER BY r.date_created DESC
";

$result = mysqli_query($con, $query);

// Check if the query was successful
if (!$result) {
    die("Error: " . mysqli_error($con));
}

// Fetch and display the results
while ($row = mysqli_fetch_assoc($result)) { 
    echo '<div class="container-fluid">';
    echo '<div><h2>' . htmlspecialchars($row["user_name"]) . '</h2><hr style="border-top: 5px dashed #777"></div>';
    echo '<div><h3>' . htmlspecialchars($row["review_heading"]) . '</h3></div>';
    echo '<div><p>' . htmlspecialchars($row["review_body"]) . '</p></div>';
    echo '<div class="review-item">';
    echo '<p class="review-date">Date reviewed: ' . htmlspecialchars($row["date_created"]) . '</p>';

    echo '</div>';
    echo '</div>';
    echo '<hr>';
}
?>
