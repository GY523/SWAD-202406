<?php
require('../Model/database.php');
include('../Controller/auth.php');

if (!isset($_GET['movie_id']) || empty($_GET['movie_id'])) {
    die("No movie ID specified.");
}
$movie_id = mysqli_real_escape_string($con, $_GET['movie_id']);
$sel_query="SELECT * FROM movie WHERE movie_id='$movie_id';";
$result2=mysqli_query($con,$sel_query) or die(mysqli_error($con));
$row= mysqli_fetch_assoc($result2);
$title= $row['title'] ?? "";

if(isset($_POST['new']) && $_POST['new'] == 1) {
    $movie_id = mysqli_real_escape_string($con, $_GET['movie_id']);
    $user_id = mysqli_real_escape_string($con, $_SESSION['user_id']);
    $review_heading = mysqli_real_escape_string($con, $_POST['review_heading']);
    $review_body = mysqli_real_escape_string($con, $_POST['review_body']);
    $has_spoiler = mysqli_real_escape_string($con, $_POST['has_spoiler']);

    // Check if user already reviewed
    $check_query = "SELECT * FROM rate_and_review WHERE movie_id = '$movie_id' AND user_id='$user_id'";
    $result = mysqli_query($con, $check_query) or die(mysqli_error($con));

    if(mysqli_num_rows($result) > 0){
        include('../Controller/update_rev.php');
    } else {
        include('../Controller/insert_rev.php');
    }
    
    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../View/style.css">
    <title>Review</title>
    <style>
        .rating-container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .movie-title {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .average-rating {
            font-size: 18px;
            margin-bottom: 20px;
        }
        .rating-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .rating-stars {
            font-size: 50px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        .star {
            color: #ccc;
        }
        .star.active {

            color: yellow;
        }
        .rating-form input[type="text"],
        .rating-form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .rating-form button {
            background-color: #28a745;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        .rating-form button:hover {
            background-color: #218838;
        }
        
    </style>
</head>
<body>
    <?php 
    include ('../View/header.html');
    ?>
    <div id="site-content">
        <main class="main-content">
            <div class="container">
                <div class="rating-container">
                    <h3>Your Review</h3>
                    <form action="" method="post">
                        <input type="hidden" name="new" value="1" />
                        <input type="hidden" name="movie_id" value="<?php echo htmlspecialchars($movie_id, ENT_QUOTES, 'UTF-8'); ?>" />
                        <div class="form-group">
                            <input type="text" id="review_heading" name="review_heading" placeholder="Headline for review" maxlength="200" required>
                        </div>
                        <p>Max characters: 600</p>

                        <div class="form-group">
                            <textarea id="review_body" name="review_body" placeholder="Your review" maxlength="10000" rows="6" required></textarea>
                        </div>

                        <div class="form-group radio-group">
                            <h6>Contain spoiler?</h6>
                            <input type="radio" id="spoiler_yes" name="has_spoiler" value="1" required>
                            <label for="spoiler_yes">Yes</label>
                            <input type="radio" id="spoiler_no" name="has_spoiler" value="0" required>
                            <label for="spoiler_no">No</label>
                        </div>

                        <button type="submit">Submit Review</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <?php
    include ('../View/footer.html');
    ?>



</body>
</html>
