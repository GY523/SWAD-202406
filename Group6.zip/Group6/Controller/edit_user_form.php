<?php
include('../Controller/auth.php');
require('../Model/database.php');

$user_id = $_SESSION["user_id"]; // get the logged in user's id

// pre filled user's original informarion
$query = "SELECT * FROM user WHERE user_id='$user_id'";
$result = mysqli_query($con, $query);
$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Edit User Information</title>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f4f4f4;
    }

    /* Centering the form container */
    .form {
        border: 1px solid #ccc;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 350px;
        box-sizing: border-box;
        text-align: center; /* make the contain align to center */
    }

    .form h1 {
        margin-top: 0;
    }

    .form input[type="text"],
    .form input[type="password"],
    .form input[type="number"],
    .form input[type="email"],
    .form input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin: 8px 0;
        box-sizing: border-box; 
    }

    .form input[type="submit"] {
        box-sizing: border-box;
        background-color: #007AFF;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .form p {
        margin: 10px 0;
    }

    .form a {
        display: block;
        margin-top: 10px;
    }
</style>
</head>
<body>
<div class="form">
<h1>Edit Your Information</h1>
<form name="editUserInfo" action="update_user.php" method="post">
    <input type="text" name="username" value="<?php echo $user['user_name']; ?>" placeholder="Username" required /><br>
    <input type="email" name="email" value="<?php echo $user['user_email']; ?>" placeholder="Email" required /><br>
    <input type="number" name="age" value="<?php echo $user['user_age']; ?>" placeholder="age" required /><br>
    <input type="text" name="country" value="<?php echo $user['user_country']; ?>" placeholder="Country" required /><br>
    <input type="submit" name="submit" value="Update" />
</form>
</div>
</body>
</html>