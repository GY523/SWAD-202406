<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>User Login</title>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f4f4f4;
    }

    /* make the form container center */
    .form {
        border: 1px solid #ccc;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        box-sizing: border-box;
        text-align: center; /* make the contain align to center */
    }

    .form h1 {
        margin-top: 0;
    }

    .form input[type="text"],
    .form input[type="password"],
    .form input[type="number"],
    .form input[type="email"],
    .form input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin: 8px 0;
        box-sizing: border-box;
    }

    .form input[type="submit"] {
        box-sizing: border-box;
        background-color: #007AFF;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .form p {
        margin: 10px 0;
    }

    .form a {
        display: block;
        margin-top: 10px;
    }
</style>
</head>
<body>
<?php

require('../Model/database.php');

if (isset($_POST['username']) && isset($_POST['password'])) {
    if($_POST['username']=='admin' && $_POST['password']=='group6'){
        $_SESSION['admin']=1;
        $_SESSION['lastTimestamp'] = time();
        header("location: ../View/admin_data_manager.php");
        exit();
    }
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);

    // Build and display the query for debugging purposes
    $hashedPassword = md5($password);
    $query = "SELECT * 
              FROM user 
              WHERE user_name='$username' 
              AND user_password='$hashedPassword'";


    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $rows = mysqli_num_rows($result);

    if ($rows == 1) {
        $userData = mysqli_fetch_assoc($result);
        echo "User found: " . print_r($userData, true); // Display user data for debugging
        $_SESSION['user_name'] = $userData['user_name'];
        $_SESSION['user_id'] = $userData['user_id'];
        $_SESSION['lastTimestamp'] = time();

        if (isset($_POST['remember_me'])) {
            $cookie_name = "user";
            $cookie_value = $username;
            $expiration_time = time() + 60 * 60 * 24 * 30; // 30 days
            setcookie($cookie_name, $cookie_value, $expiration_time, "/", "", true, true); // Secure, HttpOnly
        }
        header("Location:../View/index.php");
        exit();
    } else {
        echo "<div class='form'>
        <h3>Username/password is incorrect.</h3>
        <br/>Click here to <a href='login.php'>Login</a></div>";
    }
}
else
   {
?>

<div class="form">
<h1>User Log In</h1>
<form action="" method="post" name="login">
<input type="text" name="username" placeholder="Username" required /><br>
<input type="password" name="password" placeholder="Password" required /><br>
<p>
 <label>Remember Me</label>
 <input type="checkbox" name="remember_me" id="remember_me">
</p>
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
</div>
<?php } ?>
</body>
</html>