<?php
include('../Controller/auth.php');
require('../Model/database.php');


$user_id = $_SESSION['user_id']; // get the logged in user's id

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // handle form submission from edit_user_form to database
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $email = stripslashes($_POST['email']);
    $email = mysqli_real_escape_string($con, $email);
    $age = stripslashes($_POST['age']);
    $age = mysqli_real_escape_string($con, $age);
    $country = stripslashes($_POST['country']);
    $country = mysqli_real_escape_string($con, $country);

    $query= "UPDATE user SET user_name='$username', user_email='$email', user_age='$age', user_country='$country' WHERE user_id=$user_id";
    // update user information to the database
    if (mysqli_query($con, $query)) {
        echo "<script>
                alert('Your information has been updated successfully.');
                window.location.href = '../View/user.php'; // Redirect to user profile page
              </script>";
    } else {
        echo "<script>
                alert('There was an error updating your information.');
                window.location.href = '../Controller/edit_user_form.php'; // Redirect back to the edit form
              </script>";
    }
} else {
    echo "<script>
            alert('Invalid request.');
            window.location.href = '../Controller/edit_user_form.php'; // Redirect back to the edit form
          </script>";
}
?>