<?php
$date_created = date("Y-m-d");


$movie_id = mysqli_real_escape_string($con, $movie_id);
$user_id = mysqli_real_escape_string($con, $user_id);
$review_heading = mysqli_real_escape_string($con, $review_heading);
$review_body = mysqli_real_escape_string($con, $review_body);
$has_spoiler = mysqli_real_escape_string($con, $has_spoiler);


$update = "UPDATE rate_and_review 
           SET review_heading = '$review_heading', 
               review_body = '$review_body', 
               has_spoiler = '$has_spoiler', 
               date_created = '$date_created' 
           WHERE movie_id = '$movie_id' 
           AND user_id = '$user_id'";


$result = mysqli_query($con, $update);


if ($result) {

    echo "<script>
    alert('Review updated successfully');
  </script>";
} else {
    echo "<script>
    alert('Review update failed');
  </script>" . mysqli_error($con);
}
?>
