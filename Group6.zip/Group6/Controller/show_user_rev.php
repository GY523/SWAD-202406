<?php

$query = "
    SELECT r.movie_id, m.title, r.review_heading, r.review_body, r.date_created
    FROM rate_and_review r
    INNER JOIN movie m ON r.movie_id = m.movie_id
    WHERE r.user_id = '$user_id'
    ORDER BY r.date_created DESC
";

$result = mysqli_query($con, $query);


if (!$result) {
    die("Error: " . mysqli_error($con));
}


while ($row = mysqli_fetch_assoc($result)) { 
    echo '<div class="container-fluid">';
    echo '<div><h3>' . htmlspecialchars($row["title"]) . '</h3></div>';
    echo '<div><h3>' . htmlspecialchars($row["review_heading"]) . '</h3></div>';
    echo '<div><p>' . htmlspecialchars($row["review_body"]) . '</p></div>';
    echo '<div class="review-item">';
    echo '<p class="review-date">Date reviewed: ' . htmlspecialchars($row["date_created"]) . '</p>';
    echo '<p><a href="../Controller/delete_rev.php?id=' . htmlspecialchars($row["movie_id"]) . '" onclick="return confirm(\'Are you sure you want to delete this review?\')">Delete</a>';
    echo '&emsp;'.'<a href="../Controller/review.php?movie_id=' . htmlspecialchars($row["movie_id"]) . '">Edit</a></p>';


    echo '</div>';
    echo '</div>';
    echo '<hr>';
}
?>