<?php
require('../Model/database.php');

$id = $_GET['user_id'];
$query = "DELETE FROM user WHERE user_id=$id"; 

if (mysqli_query($con, $query)) {
    echo "<script>
            alert('Your account has been deleted.');
            window.location.href = 'login.php';
          </script>";
} else {
    echo "<script>
            alert('There was an error deleting your account.');
            window.location.href = 'login.php';
          </script>";
}
?>
