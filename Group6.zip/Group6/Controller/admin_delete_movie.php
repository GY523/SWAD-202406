<?php
require('../Model/database.php');
include('../Controller/admin_auth.php');
$movie_id=$_GET['movie_id'];
$del_query= "DELETE from movie WHERE movie_id='$movie_id';";
$result= mysqli_query($con,$del_query) or die(mysqli_error($con));
$msg="Movie with id $movie_id has been deleted!";
header("Location: ../View/admin_data_manager.php?table=movie&msg='$msg'");
exit();

?>