<?php

function showAllFromTable($table_name,$con){
    //query to get all data from a table
    $sel_query= "SELECT * FROM $table_name;";
    $result=mysqli_query($con,$sel_query);

    //check for the table name to decide the form
    if($table_name=='movie')
        $page_for_insert='admin_insert_movie.php';
    else if($table_name=='user')
        $page_for_insert='admin_insert_user.php';
    else if($table_name=='rate_and_review')
        $page_for_insert='admin_insert_rate_and_review.php';
    else{
        echo "issues with table_name";
        exit();
    }  

    //print out the anchor for the page to create new
    echo "<a href='$page_for_insert'>Create new</a>";

    if(mysqli_num_rows($result)> 0){
        echo '<table border="1" style="table-layout: auto; width:auto;">';
        echo '<tr>';

        //header row
        echo '<th>Select</th>';

        //fetch the column name dynamically
        $field_info= mysqli_fetch_fields($result);
        foreach($field_info as $field){
            echo '<th>'. $field->name . '</th>';
        }
        echo '</tr>'; //end of header row
        
        //get the name of the id column( to be used to retrieve every id)
        mysqli_field_seek($result,0);
        $id_field=mysqli_fetch_field($result);
        $id_field_name=$id_field->name;

        //rate_and_view table has a composite key
        if($table_name=="rate_and_review"){
            $sec_id_field=mysqli_fetch_field($result);
            $sec_id_field_name=$sec_id_field->name;
        }

        //fetch and display the data row by row
        while($row=mysqli_fetch_assoc($result)){
            //open new row
            echo "<tr>";
            //radiobutton with unique id
            if($table_name=='movie')
                echo '<td><a href="../View/admin_update_movie.php?movie_id='. $row[$id_field_name].'">Edit</a>
                <a href="../Controller/admin_delete_movie.php?movie_id='.$row[$id_field_name].'">Delete</a></td>';
            else if($table_name=='rate_and_review')
                echo '<td><a href="admin_update_rate_and_review.php?movie_id='.$row[$id_field_name].'&user_id='.$row[$sec_id_field_name].'">Edit</a>
                <a href="admin_delete_rate_and_review.php?movie_id='.$row[$id_field_name].'&user_id='.$row[$sec_id_field_name].'">Delete</a></td>';
            else if($table_name=='user')
                echo '<td><a href="admin_update_user.php?user_id='. $row[$id_field_name].'">Edit</a>
                <a href="admin_delete_user.php?user_id='.$row[$id_field_name].'">Delete</a></td>';
            //print each value in the assoc array
            foreach($row as $value){
                echo '<td><p>'. htmlspecialchars($value). '</p></td>';
            }
            echo '</label></tr>';
        }
        echo '</table>';

    }else{
        echo "<p>No records found. Create a new one.</p>";

    }
}
/*
//different table will show different form input
function printFormForTable($table_name){
    if($table_name=='movie'){
        echo '<label for="title">Title:</label><br>';
        echo '<input type="text" id="title" name="title" required><br><br>';

        echo '<label for="image">Image URL:</label><br>';
        echo '<input type="url" id="image" name="image" required><br><br>';

        echo '<label for="released_year">Released Year:</label><br>';
        echo '<input type="number" id="released_year" name="released_year" min="1900" max="2099" step="1" required><br><br>';

        echo '<label for="language">Language:</label><br>';
        echo '<input type="text" id="language" name="language" required><br><br>';

        echo '<label for="runtime">Runtime (minutes):</label><br>';
        echo '<input type="number" id="runtime" name="runtime" min="1" required><br><br>';

        echo '<label for="genre">Genre:</label><br>';
        echo '<input type="text" id="genre" name="genre" required><br><br>';

        echo '<label for="overview">Overview:</label><br>';
        echo '<textarea id="overview" name="overview" rows="4" cols="50" required></textarea><br><br>';

        echo '<label for="tagline">Tagline:</label><br>';
        echo '<input type="text" id="tagline" name="tagline" required><br><br>';

        echo '<label for="cast">Cast:</label><br>';
        echo '<textarea id="cast" name="cast" rows="4" cols="50" required></textarea><br><br>';

        echo '<label for="director">Director:</label><br>';
        echo '<input type="text" id="director" name="director" required><br><br>';    
    }else if($table_name=='user'){
        echo '<!-- User Name -->
        <label for="user_name">Name:</label><br>
        <input type="text" id="user_name" name="user_name" required><br><br>

        <!-- User Email -->
        <label for="user_email">Email:</label><br>
        <input type="email" id="user_email" name="user_email" required><br><br>

        <!-- User Password -->
        <label for="user_password">Password:</label><br>
        <input type="password" id="user_password" name="user_password" required><br><br>

        <!-- User Country -->
        <label for="user_country">Country:</label><br>
        <input type="text" id="user_country" name="user_country" required><br><br>

        <!-- User Birthyear -->
        <label for="user_birthyear">Birth Year:</label><br>
        <input type="number" id="user_birthyear" name="user_birthyear" min="1900" max="2099" step="1" required><br><br>

        <!-- Registration Date -->
        <label for="reg_date">Registration Date:</label><br>
        <input type="date" id="reg_date" name="reg_date" required><br><br>';
    }else if($table_name=='rate_and_review'){
        echo '<!-- Date Created -->
        <label for="date_created">Date Created:</label><br>
        <input type="date" id="date_created" name="date_created" required><br><br>

        <!-- Rating -->
        <label for="rating">Rating (1-10):</label><br>
        <input type="number" id="rating" name="rating" min="1" max="10" required><br><br>

        <!-- Review Heading -->
        <label for="review_heading">Review Heading:</label><br>
        <input type="text" id="review_heading" name="review_heading" required><br><br>

        <!-- Review Body -->
        <label for="review_body">Review Body:</label><br>
        <textarea id="review_body" name="review_body" rows="6" cols="50" required></textarea><br><br>

        <!-- Has Spoiler -->
        <label for="has_spoiler">Does this review contain spoilers?</label><br>
        <input type="checkbox" id="has_spoiler" name="has_spoiler" value="1"><br><br>';
    }
}
*/
?>