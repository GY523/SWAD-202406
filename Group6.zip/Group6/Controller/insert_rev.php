<?php
$date_created = date("Y-m-d");


$movie_id = mysqli_real_escape_string($con, $movie_id);
$user_id = mysqli_real_escape_string($con, $user_id);
$review_heading = mysqli_real_escape_string($con, $review_heading);
$review_body = mysqli_real_escape_string($con, $review_body);
$has_spoiler = mysqli_real_escape_string($con, $has_spoiler);

$insert = "INSERT INTO rate_and_review (movie_id, user_id, date_created, review_heading, review_body, has_spoiler) 
           VALUES ('$movie_id', '$user_id', '$date_created', '$review_heading', '$review_body', '$has_spoiler')";

if (mysqli_query($con, $insert)) {
    echo "<script>
    alert('Review sumbmitted successfully');
  </script>";
} else {
    echo "<script>
    alert('Review sumbit failed');
  </script>" . mysqli_error($con);
}
?>
