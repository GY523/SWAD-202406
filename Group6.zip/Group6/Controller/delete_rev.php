<?php

require("../Model/database.php");
include('../Controller/auth.php');



if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("No movie ID specified.");
}


$movie_id = mysqli_real_escape_string($con, $_GET['id']);


$user_id = mysqli_real_escape_string($con, $_SESSION['user_id']);


$query = "DELETE  FROM rate_and_review
          WHERE user_id = '$user_id' 
          AND movie_id = '$movie_id'";


if (mysqli_query($con, $query)) {
    echo "<script>
    alert('Review deleted successfully');
    window.location.href = '../View/user.php'; // Redirect to the page listing reviews
    </script>";
} else {
    echo "<script>
    alert('Record delete failed');
    </script>" . mysqli_error($con);
}
?>
