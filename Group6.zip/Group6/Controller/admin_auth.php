<?php
session_start();
$logoutTime = 30; // 10 sec for test
if(!isset($_SESSION["admin"]) || time() - $_SESSION['lastTimestamp'] > $logoutTime){

    session_unset();
    session_destroy();
    header("Location: ../Controller/login.php?session_expired=1");
    exit(); 
} else {
    session_regenerate_id(true);
    $_SESSION['lastTimestamp'] = time(); // refresh the last timestamp
}
?>
<html>
    <head>
        <meta http-equiv="refresh" content="60">
    </head>
</html>